
package juego_pacman;

import java.awt.EventQueue;
import javax.swing.JFrame;
import static javax.swing.JFrame.EXIT_ON_CLOSE;

public class Juego_Pacman extends JFrame {
    
    public Juego_Pacman() {
        
        initUI();
    }
    
    private void initUI() {
        add(new Tablero());
        setSize(500, 550);
        setLocationRelativeTo(null);
        setVisible(true);        
    }

    public static void main(String[] args) { 
       Inicio i = new Inicio();
       i.setVisible(true);
       i.setLocationRelativeTo(null);
       i.setVisible(true);
       i.setSize(960,570);
       i.setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
    
}
